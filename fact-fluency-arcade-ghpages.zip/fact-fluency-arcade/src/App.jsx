import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ResponsiveContainer,
  BarChart,
  Bar,
  Legend,
} from "recharts";

/**
 * Fact Fluency Arcade – single‑file React app
 *
 * Features
 * - Student login with nickname; class list persists to localStorage.
 * - Three modes: Practice (untimed), Sprint (timed), Challenge (mixed ops).
 * - Operations: + − × with adjustable ranges and difficulty.
 * - Adaptive problem generator weights missed/slow facts more often.
 * - Immediate feedback, streaks, stars, and gentle hints.
 * - Teacher Dashboard (PIN by default: 1234) with charts (per‑student & class).
 * - Exports CSV/JSON; imports JSON to merge classes.
 * - Privacy: all data stays in the browser unless you export it.
 *
 * How to use
 * - Click “Teacher” (lower right) → enter PIN → view dashboard.
 * - Change PIN in Settings once inside teacher view.
 * - Students choose their name (or create one) and press Play.
 */

const STORAGE_KEY = "ff_arcade_v1";

type Operation = "+" | "-" | "×"; // use × symbol for kid-friendly look

interface Attempt {
  ts: number; // epoch ms
  student: string;
  op: Operation;
  a: number;
  b: number;
  answer: number; // student answer
  correct: boolean;
  ms: number; // response time
}

interface Student {
  name: string;
  createdAt: number;
  lastSeen: number;
}

interface Settings {
  pin: string; // teacher PIN
  sprintSeconds: number;
  targetFactsPerSession: number;
  speedThresholdMs: number; // what counts as "fluent"
  addMax: number;
  subMax: number;
  mulMax: number;
}

interface DataShape {
  students: Record<string, Student>;
  attempts: Attempt[];
  settings: Settings;
}

const defaultSettings: Settings = {
  pin: "1234",
  sprintSeconds: 60,
  targetFactsPerSession: 20,
  speedThresholdMs: 4000,
  addMax: 20,
  subMax: 20,
  mulMax: 12,
};

function loadData(): DataShape {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) {
    return { students: {}, attempts: [], settings: defaultSettings };
  }
  try {
    const obj = JSON.parse(raw);
    return {
      students: obj.students || {},
      attempts: obj.attempts || [],
      settings: { ...defaultSettings, ...(obj.settings || {}) },
    } as DataShape;
  } catch (e) {
    console.error("Failed to parse data; resetting.", e);
    return { students: {}, attempts: [], settings: defaultSettings };
  }
}

function saveData(d: DataShape) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(d));
}

function compute(op: Operation, a: number, b: number): number {
  switch (op) {
    case "+":
      return a + b;
    case "-":
      return a - b;
    case "×":
      return a * b;
  }
}

function factKey(op: Operation, a: number, b: number) {
  if (op === "+" || op === "×") {
    const [x, y] = a < b ? [a, b] : [b, a];
    return `${x}${op}${y}`;
  }
  return `${a}${op}${b}`; // subtraction is ordered
}

interface GenConfig {
  op: Operation | "mix";
  addMax: number;
  subMax: number;
  mulMax: number;
  history: Attempt[]; // for adaptivity
}

function pickWeighted(items: { item: any; w: number }[]) {
  const total = items.reduce((s, it) => s + it.w, 0);
  let r = Math.random() * total;
  for (const it of items) {
    if ((r -= it.w) <= 0) return it.item;
  }
  return items[items.length - 1].item;
}

function nextProblem(cfg: GenConfig): { op: Operation; a: number; b: number } {
  const op: Operation =
    cfg.op === "mix"
      ? pickWeighted([
          { item: "+", w: 1 },
          { item: "-", w: 1 },
          { item: "×", w: 1 },
        ])
      : (cfg.op as Operation);

  const max = op === "+" ? cfg.addMax : op === "-" ? cfg.subMax : cfg.mulMax;

  let pool: { a: number; b: number }[] = [];
  if (op === "×") {
    for (let a = 0; a <= cfg.mulMax; a++)
      for (let b = 0; b <= cfg.mulMax; b++) pool.push({ a, b });
  } else if (op === "+") {
    for (let a = 0; a <= max; a++)
      for (let b = 0; b <= max; b++) if (a + b <= max) pool.push({ a, b });
  } else if (op === "-") {
    for (let a = 0; a <= max; a++)
      for (let b = 0; b <= a; b++) pool.push({ a, b });
  }

  const recent = cfg.history.slice(-150);
  const weights = new Map<string, number>();
  for (const p of pool) {
    weights.set(factKey(op, p.a, p.b), 1);
  }
  for (const at of recent) {
    if (at.op !== op) continue;
    const key = factKey(op, at.a, at.b);
    const base = weights.get(key) ?? 1;
    if (!at.correct) {
      weights.set(key, base + 3);
    } else if (at.ms > 4000) {
      weights.set(key, base + 1);
    } else {
      weights.set(key, Math.max(0.5, base - 0.2));
    }
  }

  const choice = pickWeighted(
    pool.map((p) => ({ item: p, w: weights.get(factKey(op, p.a, p.b)) ?? 1 }))
  );

  return { op, a: choice.a, b: choice.b };
}

function msFmt(ms: number) {
  return `${(ms / 1000).toFixed(2)}s`;
}

export default function FactFluencyArcade() {
  const [data, setData] = useState(() => loadData());
  const [view, setView] = useState({ kind: "login" } as
    | { kind: "login" }
    | { kind: "play"; student: string }
    | { kind: "teacher" });

  useEffect(() => saveData(data), [data]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-indigo-50 text-slate-800">
      <header className="p-4 sm:p-6 flex items-center justify-between">
        <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
          Fact Fluency Arcade
        </h1>
        <div className="flex items-center gap-2 text-sm">
          <span className="hidden sm:inline">Grade 3 • + − ×</span>
          <button
            className="px-3 py-1.5 rounded-xl bg-slate-800 text-white hover:opacity-90"
            onClick={() => setView({ kind: "login" })}
            aria-label="Go to student login"
          >
            Students
          </button>
          <TeacherDoor data={data} enter={() => setView({ kind: "teacher" })} />
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-4 sm:p-6">
        {view.kind === "login" && (
          <Login data={data} setData={setData} onStart={(s) => setView({ kind: "play", student: s })} />
        )}
        {view.kind === "play" && (
          <PlayView student={view.student} data={data} setData={setData} back={() => setView({ kind: "login" })} />
        )}
        {view.kind === "teacher" && (
          <TeacherView data={data} setData={setData} exit={() => setView({ kind: "login" })} />
        )}
      </main>
      <footer className="text-center text-xs text-slate-500 py-6">All progress is saved in this browser. Export to back up.</footer>
    </div>
  );
}

function Login({ data, setData, onStart }) {
  const [name, setName] = useState("");
  const names = Object.keys(data.students).sort();
  const addStudent = () => {
    const n = name.trim();
    if (!n) return;
    if (data.students[n]) {
      onStart(n);
      return;
    }
    setData((d) => ({
      ...d,
      students: {
        ...d.students,
        [n]: { name: n, createdAt: Date.now(), lastSeen: Date.now() },
      },
    }));
    onStart(n);
  };

  return (
    <div className="grid gap-6 sm:grid-cols-2">
      <div className="bg-white/70 backdrop-blur p-6 rounded-2xl shadow">
        <h2 className="text-xl font-bold mb-2">Choose Your Name</h2>
        <div className="flex gap-2 mb-3">
          <input
            className="flex-1 px-3 py-2 rounded-xl border"
            placeholder="Type your name (e.g., Jordan)"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <button className="px-3 py-2 rounded-xl bg-indigo-600 text-white" onClick={addStudent}>
            Play
          </button>
        </div>
        {names.length > 0 && (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {names.map((n) => (
              <button
                key={n}
                className="px-3 py-2 rounded-xl bg-indigo-50 hover:bg-indigo-100 border"
                onClick={() => onStart(n)}
              >
                {n}
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="bg-white/70 backdrop-blur p-6 rounded-2xl shadow">
        <h2 className="text-xl font-bold mb-2">Game Modes</h2>
        <ul className="list-disc pl-6 space-y-2 text-slate-700">
          <li>
            <b>Practice:</b> Untimed; earn stars by answering correctly.
          </li>
          <li>
            <b>Sprint:</b> {data.settings.sprintSeconds}s dash — how many can you get?
          </li>
          <li>
            <b>Challenge:</b> Mixed + − × with adaptive practice.
          </li>
        </ul>
      </div>
    </div>
  );
}

function TeacherDoor({ data, enter }) {
  const [open, setOpen] = useState(false);
  const [pin, setPin] = useState("");
  return (
    <div className="relative">
      <button
        className="px-3 py-1.5 rounded-xl bg-emerald-600 text-white hover:opacity-90"
        onClick={() => setOpen((o) => !o)}
      >
        Teacher
      </button>
      {open && (
        <div className="absolute right-0 mt-2 w-64 bg-white shadow-xl border rounded-xl p-3 z-10">
          <div className="text-sm mb-2">Enter PIN</div>
          <input
            className="w-full px-3 py-2 border rounded-xl mb-2"
            type="password"
            placeholder="1234"
            value={pin}
            onChange={(e) => setPin(e.target.value)}
          />
          <button
            className="w-full px-3 py-2 rounded-xl bg-slate-800 text-white"
            onClick={() => {
              if (pin === data.settings.pin) enter();
              else alert("Incorrect PIN");
            }}
          >
            Enter
          </button>
        </div>
      )}
    </div>
  );
}

function PlayView({ student, data, setData, back }) {
  const [mode, setMode] = useState("practice");
  const [op, setOp] = useState("+");
  const [current, setCurrent] = useState(null);
  const [input, setInput] = useState("");
  const [startMs, setStartMs] = useState(null);
  const [timeLeft, setTimeLeft] = useState(data.settings.sprintSeconds);
  const [sessionCount, setSessionCount] = useState(0);
  const [streak, setStreak] = useState(0);
  const inputRef = useRef(null);

  const attemptsForStudent = useMemo(
    () => data.attempts.filter((a) => a.student === student),
    [data.attempts, student]
  );

  useEffect(() => {
    setData((d) => ({
      ...d,
      students: {
        ...d.students,
        [student]: { ...(d.students[student] || { name: student, createdAt: Date.now() }), lastSeen: Date.now() },
      },
    }));
  }, [student]);

  useEffect(() => {
    if (!current) newProblem();
  }, [op, mode]);

  useEffect(() => {
    if (mode !== "sprint") return;
    setTimeLeft(data.settings.sprintSeconds);
    const id = setInterval(() => setTimeLeft((t) => (t > 0 ? t - 1 : 0)), 1000);
    return () => clearInterval(id);
  }, [mode, data.settings.sprintSeconds]);

  useEffect(() => {
    if (mode === "sprint" && timeLeft === 0) {
      alert(`Sprint finished! You answered ${sessionCount} facts.`);
      setSessionCount(0);
      setMode("practice");
    }
  }, [timeLeft, mode, sessionCount]);

  function newProblem() {
    const cfg = {
      op,
      addMax: data.settings.addMax,
      subMax: data.settings.subMax,
      mulMax: data.settings.mulMax,
      history: attemptsForStudent,
    };
    const p = nextProblem(cfg);
    setCurrent(p);
    setInput("");
    setStartMs(Date.now());
    setTimeout(() => inputRef.current?.focus(), 0);
  }

  function submit() {
    if (!current || startMs == null) return;
    const correctAnswer = compute(current.op, current.a, current.b);
    const ans = Number(input);
    const ok = ans === correctAnswer;
    const ms = Date.now() - startMs;

    const attempt = {
      ts: Date.now(),
      student,
      op: current.op,
      a: current.a,
      b: current.b,
      answer: ans,
      correct: ok,
      ms,
    };

    setData((d) => ({ ...d, attempts: [...d.attempts, attempt] }));

    setSessionCount((c) => c + 1);
    setStreak((s) => (ok ? s + 1 : 0));

    if (!ok) {
      const hint = hintFor(current.op, current.a, current.b);
      alert(`Not quite. Try again. Hint: ${hint}`);
      setStartMs(Date.now());
      setInput("");
      return;
    }

    if (ok && (sessionCount + 1) % 5 === 0) {
      toast(`Nice! ${sessionCount + 1} correct so far! ⭐`);
    }

    newProblem();
  }

  function toast(msg) {
    const el = document.createElement("div");
    el.textContent = msg;
    el.className =
      "fixed bottom-6 left-1/2 -translate-x-1/2 bg-black text-white px-4 py-2 rounded-xl shadow z-50";
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 1400);
  }

  return (
    <div className="grid lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2 bg-white rounded-2xl shadow p-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="text-lg font-bold">Player: {student}</div>
          <div className="flex gap-2">
            {["practice", "sprint", "challenge"].map((m) => (
              <button
                key={m}
                className={`px-3 py-1.5 rounded-xl border ${mode === m ? "bg-indigo-600 text-white" : "bg-indigo-50"}`}
                onClick={() => setMode(m)}
              >
                {m[0].toUpperCase() + m.slice(1)}
              </button>
            ))}
          </div>
          <div className="flex gap-2">
            {["+", "-", "×", "mix"].map((o) => (
              <button
                key={o}
                className={`px-3 py-1.5 rounded-xl border ${op === o ? "bg-emerald-600 text-white" : "bg-emerald-50"}`}
                onClick={() => setOp(o)}
              >
                {o}
              </button>
            ))}
          </div>
          <button className="px-3 py-1.5 rounded-xl border" onClick={back}>
            Back
          </button>
        </div>

        {mode === "sprint" && (
          <div className="mt-4 text-center text-sm">
            Time left: <b>{timeLeft}s</b>
          </div>
        )}

        <div className="mt-6 flex flex-col items-center">
          {current && (
            <div className="text-6xl sm:text-7xl font-black tracking-wide select-none">
              {current.a} {current.op} {current.b} =
            </div>
          )}
          <input
            ref={inputRef}
            className="mt-6 text-center text-4xl w-48 px-4 py-3 border rounded-2xl"
            inputMode="numeric"
            value={input}
            onChange={(e) => setInput(e.target.value.replace(/[^0-9-]/g, ""))}
            onKeyDown={(e) => e.key === "Enter" && submit()}
            placeholder="?"
          />
          <div className="mt-4 flex items-center gap-4 text-sm">
            <button className="px-3 py-1.5 rounded-xl bg-indigo-600 text-white" onClick={submit}>
              Submit
            </button>
            <button className="px-3 py-1.5 rounded-xl border" onClick={newProblem}>
              Skip
            </button>
            <span>
              Streak: <b>{streak}</b>
            </span>
            <span>
              This session: <b>{sessionCount}</b>
            </span>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow p-6">
        <h3 className="font-bold mb-2">Today’s Progress</h3>
        <MiniProgress attempts={attemptsForStudent} settings={data.settings} />
        <h3 className="font-bold mt-6 mb-2">Focus Facts (you’re still growing)</h3>
        <FocusFacts attempts={attemptsForStudent} />
      </div>
    </div>
  );
}

function hintFor(op, a, b) {
  if (op === "+") return `Make a ten: ${a} + ${b} → ${a + (10 - (a % 10 || 10))}`;
  if (op === "-") return `Count back ${b} from ${a}.`;
  return `Arrays: ${a} rows of ${b}.`;
}

function MiniProgress({ attempts, settings }) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const list = attempts.filter((a) => a.ts >= today.getTime());
  const correct = list.filter((a) => a.correct).length;
  const avgMs = list.length ? Math.round(list.reduce((s, a) => s + a.ms, 0) / list.length) : 0;
  return (
    <div className="text-sm">
      <div className="mb-1">Facts answered: <b>{list.length}</b></div>
      <div className="mb-1">Correct: <b>{correct}</b> ({list.length ? Math.round((correct / list.length) * 100) : 0}%)</div>
      <div className="mb-1">Avg time: <b>{avgMs ? msFmt(avgMs) : "–"}</b> (goal ≤ {msFmt(settings.speedThresholdMs)})</div>
    </div>
  );
}

function factKeyJS(op, a, b) {
  if (op === "+" || op === "×") {
    const [x, y] = a < b ? [a, b] : [b, a];
    return `${x}${op}${y}`;
  }
  return `${a}${op}${b}`;
}

function FocusFacts({ attempts }) {
  const cutoff = Date.now() - 7 * 24 * 3600 * 1000;
  const recent = attempts.filter((a) => a.ts >= cutoff);
  const groups = new Map();
  for (const a of recent) {
    const key = factKeyJS(a.op, a.a, a.b);
    const g = groups.get(key) || { seen: 0, wrong: 0 };
    g.seen += 1;
    if (!a.correct) g.wrong += 1;
    groups.set(key, g);
  }
  const ranked = Array.from(groups.entries())
    .map(([k, v]) => ({ k, rate: v.seen ? v.wrong / v.seen : 0, seen: v.seen }))
    .filter((x) => x.seen >= 2)
    .sort((a, b) => b.rate - a.rate)
    .slice(0, 5);
  if (!ranked.length) return <div className="text-sm text-slate-600">Keep playing to discover focus facts.</div>;
  return (
    <ul className="text-sm list-disc pl-5">
      {ranked.map((r) => (
        <li key={r.k}>
          {r.k} — needs practice ({Math.round(r.rate * 100)}% wrong)
        </li>
      ))}
    </ul>
  );
}

function TeacherView({ data, setData, exit }) {
  const [selected, setSelected] = useState("class");
  const [op, setOp] = useState("all");
  const [days, setDays] = useState(14);

  const students = Object.values(data.students).sort((a, b) => a.name.localeCompare(b.name));
  const attempts = data.attempts.filter((a) => (op === "all" ? true : a.op === op));
  const cutoff = Date.now() - days * 24 * 3600 * 1000;
  const within = attempts.filter((a) => a.ts >= cutoff);

  const classDaily = React.useMemo(() => {
    const byDay = {};
    for (const a of within) {
      const day = new Date(a.ts).toLocaleDateString();
      if (!byDay[day]) byDay[day] = { count: 0, correct: 0, avgMs: [] };
      byDay[day].count++;
      if (a.correct) byDay[day].correct++;
      byDay[day].avgMs.push(a.ms);
    }
    return Object.entries(byDay)
      .sort((a, b) => new Date(a[0]).getTime() - new Date(b[0]).getTime())
      .map(([day, v]) => ({
        day,
        answered: v.count,
        accuracy: v.count ? Math.round((v.correct / v.count) * 100) : 0,
        avgMs: v.avgMs.length ? Math.round(v.avgMs.reduce((s, x) => s + x, 0) / v.avgMs.length) : 0,
      }));
  }, [within]);

  const perStudent = React.useMemo(() => {
    const m = {};
    for (const a of within) {
      const s = (m[a.student] ||= { answered: 0, correct: 0, avgMs: [] });
      s.answered++;
      if (a.correct) s.correct++;
      s.avgMs.push(a.ms);
    }
    return Object.entries(m)
      .map(([name, v]) => ({
        name,
        answered: v.answered,
        accuracy: v.answered ? Math.round((v.correct / v.answered) * 100) : 0,
        avgMs: v.avgMs.length ? Math.round(v.avgMs.reduce((s, x) => s + x, 0) / v.avgMs.length) : 0,
      }))
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [within]);

  const selectedAttempts = within.filter((a) => (selected === "class" ? true : a.student === selected));

  function exportCSV() {
    const rows = [
      ["ts", "date", "student", "op", "a", "b", "answer", "correct", "ms"],
      ...data.attempts.map((a) => [
        a.ts,
        new Date(a.ts).toISOString(),
        a.student,
        a.op,
        a.a,
        a.b,
        a.answer,
        a.correct ? 1 : 0,
        a.ms,
      ]),
    ];
    const csv = rows.map((r) => r.join(",")).join("\\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `fact_fluency_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function exportJSON() {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `fact_fluency_backup_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function importJSON(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const obj = JSON.parse(reader.result);
        // merge students; append attempts
        setData((d) => ({
          students: { ...d.students, ...obj.students },
          attempts: [...d.attempts, ...obj.attempts],
          settings: { ...d.settings, ...(obj.settings || {}) },
        }));
        alert("Import complete");
      } catch (e) {
        alert("Import failed: invalid JSON");
      }
    };
    reader.readAsText(file);
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center gap-3">
        <button className="px-3 py-1.5 rounded-xl border" onClick={exit}>
          Exit
        </button>
        <div className="ml-auto flex gap-2">
          <button className="px-3 py-1.5 rounded-xl bg-slate-800 text-white" onClick={exportCSV}>
            Export CSV
          </button>
          <button className="px-3 py-1.5 rounded-xl bg-slate-800 text-white" onClick={exportJSON}>
            Backup JSON
          </button>
          <label className="px-3 py-1.5 rounded-xl border cursor-pointer">
            Restore JSON
            <input type="file" accept="application/json" className="hidden" onChange={importJSON} />
          </label>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow p-6">
        <div className="flex flex-wrap items-center gap-3">
          <select className="px-3 py-2 border rounded-xl" value={selected} onChange={(e) => setSelected(e.target.value)}>
            <option value="class">Whole Class</option>
            {students.map((s) => (
              <option key={s.name} value={s.name}>
                {s.name}
              </option>
            ))}
          </select>
          <select className="px-3 py-2 border rounded-xl" value={op} onChange={(e) => setOp(e.target.value)}>
            <option value="all">All Ops</option>
            <option value="+">Addition</option>
            <option value="-">Subtraction</option>
            <option value="×">Multiplication</option>
          </select>
          <label className="text-sm flex items-center gap-2">
            Last
            <input
              className="w-16 px-2 py-1 border rounded-xl"
              type="number"
              min={1}
              value={days}
              onChange={(e) => setDays(Math.max(1, Number(e.target.value)))}
            />
            days
          </label>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mt-6">
          <div className="h-64">
            <h3 className="font-bold mb-2">Daily Accuracy & Volume</h3>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={classDaily} margin={{ left: 8, right: 8, top: 8, bottom: 8 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="day" />
                <YAxis yAxisId="left" domain={[0, 100]} tickFormatter={(v) => v + "%"} />
                <YAxis yAxisId="right" orientation="right" />
                <Tooltip />
                <Legend />
                <Line yAxisId="left" type="monotone" dataKey="accuracy" name="Accuracy %" />
                <Line yAxisId="right" type="monotone" dataKey="answered" name="# Answered" />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="h-64">
            <h3 className="font-bold mb-2">Per‑Student (last {days}d)</h3>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={perStudent} margin={{ left: 8, right: 8, top: 8, bottom: 8 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" angle={-20} textAnchor="end" interval={0} height={60} />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="accuracy" name="Accuracy %" />
                <Bar dataKey="answered" name="# Answered" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <TeacherSettings data={data} setData={setData} />

      {selected !== "class" && (
        <StudentDetail student={selected} attempts={selectedAttempts} settings={data.settings} />
      )}
    </div>
  );
}

function StudentDetail({ student, attempts }) {
  const byDay = new Map();
  for (const a of attempts) {
    const day = new Date(a.ts).toLocaleDateString();
    const arr = byDay.get(day) || [];
    arr.push(a);
    byDay.set(day, arr);
  }
  const rows = Array.from(byDay.entries())
    .sort((a, b) => new Date(a[0]).getTime() - new Date(b[0]).getTime())
    .map(([day, list]) => ({
      day,
      answered: list.length,
      accuracy: Math.round((list.filter((x) => x.correct).length / list.length) * 100),
      avgMs: Math.round(list.reduce((s, x) => s + x.ms, 0) / list.length),
    }));

  return (
    <div className="bg-white rounded-2xl shadow p-6">
      <h3 className="font-bold mb-2">{student} — Progress Over Time</h3>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={rows}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="day" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="accuracy" name="Accuracy %" />
            <Line type="monotone" dataKey="answered" name="# Answered" />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <h4 className="font-semibold mt-6 mb-2">Recent Attempts</h4>
      <div className="overflow-auto border rounded-xl">
        <table className="w-full text-sm">
          <thead className="bg-slate-50">
            <tr>
              <th className="p-2 text-left">Date</th>
              <th className="p-2 text-left">Fact</th>
              <th className="p-2 text-left">Answer</th>
              <th className="p-2 text-left">Correct</th>
              <th className="p-2 text-left">Time</th>
            </tr>
          </thead>
          <tbody>
            {attempts
              .slice(-150)
              .reverse()
              .map((a, i) => (
                <tr key={i} className="odd:bg-white even:bg-slate-50">
                  <td className="p-2">{new Date(a.ts).toLocaleString()}</td>
                  <td className="p-2">
                    {a.a} {a.op} {a.b}
                  </td>
                  <td className="p-2">{a.answer}</td>
                  <td className="p-2">{a.correct ? "✓" : "✗"}</td>
                  <td className="p-2">{msFmt(a.ms)}</td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function TeacherSettings({ data, setData }) {
  const s = data.settings;
  const [pin, setPin] = useState(s.pin);
  const [sprint, setSprint] = useState(s.sprintSeconds);
  const [speed, setSpeed] = useState(s.speedThresholdMs);
  const [addMax, setAddMax] = useState(s.addMax);
  const [subMax, setSubMax] = useState(s.subMax);
  const [mulMax, setMulMax] = useState(s.mulMax);

  return (
    <div className="bg-white rounded-2xl shadow p-6">
      <h3 className="font-bold mb-3">Settings</h3>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 text-sm">
        <label className="flex items-center gap-2">PIN
          <input className="ml-auto px-2 py-1 border rounded-lg w-28" value={pin} onChange={(e) => setPin(e.target.value)} />
        </label>
        <label className="flex items-center gap-2">Sprint seconds
          <input type="number" className="ml-auto px-2 py-1 border rounded-lg w-28" value={sprint} onChange={(e) => setSprint(Number(e.target.value))} />
        </label>
        <label className="flex items-center gap-2">Fluency speed ms
          <input type="number" className="ml-auto px-2 py-1 border rounded-lg w-28" value={speed} onChange={(e) => setSpeed(Number(e.target.value))} />
        </label>
        <label className="flex items-center gap-2">Addition max sum
          <input type="number" className="ml-auto px-2 py-1 border rounded-lg w-28" value={addMax} onChange={(e) => setAddMax(Number(e.target.value))} />
        </label>
        <label className="flex items-center gap-2">Subtraction max minuend
          <input type="number" className="ml-auto px-2 py-1 border rounded-lg w-28" value={subMax} onChange={(e) => setSubMax(Number(e.target.value))} />
        </label>
        <label className="flex items-center gap-2">Multiplication max factor
          <input type="number" className="ml-auto px-2 py-1 border rounded-lg w-28" value={mulMax} onChange={(e) => setMulMax(Number(e.target.value))} />
        </label>
      </div>
      <div className="mt-4">
        <button
          className="px-3 py-1.5 rounded-xl bg-emerald-600 text-white"
          onClick={() =>
            setData((d) => ({
              ...d,
              settings: {
                ...d.settings,
                pin,
                sprintSeconds: sprint,
                speedThresholdMs: speed,
                addMax,
                subMax,
                mulMax,
              },
            }))
          }
        >
          Save Settings
        </button>
        <button
          className="ml-2 px-3 py-1.5 rounded-xl border"
          onClick={() => {
            if (confirm("Reset ALL data? This cannot be undone.")) {
              localStorage.removeItem("ff_arcade_v1");
              window.location.reload();
            }
          }}
        >
          Reset All Data
        </button>
      </div>
    </div>
  );
}
