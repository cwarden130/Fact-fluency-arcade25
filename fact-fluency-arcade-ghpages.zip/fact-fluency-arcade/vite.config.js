
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// IMPORTANT: set base to the repository name when deploying to GitHub Pages as a project site.
// Example: if your repo is https://github.com/USER/fact-fluency-arcade,
// set base to '/fact-fluency-arcade/'.
const repoBase = process.env.REPO_BASE || '/'

export default defineConfig({
  plugins: [react()],
  base: repoBase,
})
